$ATTRACTDIR/make-grid-omp $* /dev/shm/grid
