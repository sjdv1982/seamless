docking.py

Second example demonstrating the use of seamless and slash in
protein-protein docking (the 3D assembly of a protein complex from
their components).

This seamless example was developed for a live programming demonstration, and
it will be demonstrated in a video tutorial on www.youtube.com/sjdv1982.
This video tutorial is planned for August - September 2017.

See the docking/ example for another, better documented example involving
seamless, docking and slash.
