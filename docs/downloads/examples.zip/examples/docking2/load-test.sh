cat data-test.cson > data.cson
cat attrib-test.cson > attrib.cson
