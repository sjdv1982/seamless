cat data-REAL.cson > data.cson
cat attrib-REAL.cson > attrib.cson
