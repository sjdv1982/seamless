ctx.registrar.silk.connect("VertexData", ctx.gen_vertexdata)
ctx.registrar.silk.connect("VertexDataArray", ctx.gen_vertexdata)
