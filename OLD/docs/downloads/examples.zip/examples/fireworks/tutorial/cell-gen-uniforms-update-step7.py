if PINS.update.updated:
    update()
