u_time = 0
PINS.uniforms.set({
    "u_time": u_time,
})
