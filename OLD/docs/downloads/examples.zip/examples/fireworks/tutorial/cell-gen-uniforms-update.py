if PINS.reset.updated:
    new_explosion()
    
update()
