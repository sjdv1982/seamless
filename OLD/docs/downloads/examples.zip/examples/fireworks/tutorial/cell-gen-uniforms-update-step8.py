if PINS.reset.updated:
    new_explosion()
    
if PINS.update.updated:
    update()
