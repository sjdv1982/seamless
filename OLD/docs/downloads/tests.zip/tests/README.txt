This is the seamless test script directory

This directory aims to provide comprehensive tests of all features of seamless.
It is primarily meant to ensure that changes to seamless don't break things.
However, they also provide a comprehensive demonstration of the seamless API
and standard library.

For better-documented (but less comprehensive) examples, see the examples/
directory.
